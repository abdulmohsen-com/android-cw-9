package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Adapter;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Pokemon p1 = new Pokemon("Pikachu",R.drawable.pikachu, 55, 40, 320);
        Pokemon p2 = new Pokemon("Eevee",R.drawable.eevee, 55, 50, 325);
        Pokemon p3 = new Pokemon("Arceus",R.drawable.arceus, 120, 120, 720);
        Pokemon p4 = new Pokemon("Dialga",R.drawable.dialga, 120, 120, 680);
        Pokemon p5 = new Pokemon("Zekrom",R.drawable.zekrom, 120, 120, 680);

        ArrayList<Pokemon> Pokeball = new ArrayList<>();
        Pokeball.add(p1);//0
        Pokeball.add(p2);//1
        Pokeball.add(p3);//2
        Pokeball.add(p4);//3
        Pokeball.add(p5);//4
        Pokeball.add(p5);//4


        RecyclerView RV = findViewById(R.id.recycleV);
        RV.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        RV.setLayoutManager(lm);
        RV.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        PokeDapter PD = new PokeDapter(Pokeball, this);
        RV.setAdapter(PD);

    }
}