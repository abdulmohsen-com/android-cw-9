package com.example.pokemon;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.view.menu.MenuView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PokeDapter extends RecyclerView.Adapter {
    ArrayList<Pokemon> PokeRray ;
    Context context;

    public PokeDapter(ArrayList<Pokemon> pokeRray, Context context) {
        PokeRray = pokeRray;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    View vh = LayoutInflater.from(context).inflate(R.layout.pokemon_list_frame,parent, false);
    ViewHolder VH = new ViewHolder(vh);
    return VH;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        ((ViewHolder) holder).img.setImageResource(PokeRray.get(position).getImage());
        ((ViewHolder) holder).name.setText(PokeRray.get(position).getName() + "");
        ((ViewHolder) holder).total.setText(PokeRray.get(position).getTotal() + "" );
        ((ViewHolder) holder).view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Pkeinfo.class);
                intent.putExtra("pokemon", PokeRray.get(position));
                context.startActivity(intent);
            }
        });
        ((ViewHolder) holder).delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder myAlertBuilder = new AlertDialog.Builder(context);
                myAlertBuilder.setTitle("Warning");
                myAlertBuilder.setMessage("You're About To Delete The Pokemon, Are You Sure?");
                myAlertBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        PokeRray.remove(position);
                        notifyDataSetChanged();
                    }
                });
                myAlertBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                myAlertBuilder.show();


            }
        });
    }

    @Override
    public int getItemCount() {
        return PokeRray.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        View view;
        ImageView img;
        TextView name;
        TextView total;
        ImageView delete;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            img = itemView.findViewById(R.id.imageView);
            name = itemView.findViewById(R.id.name);
            total= itemView.findViewById(R.id.number);
            delete = itemView.findViewById(R.id.delete);
            }
        }
    }


