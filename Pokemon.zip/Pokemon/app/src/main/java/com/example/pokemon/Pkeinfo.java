package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Pkeinfo extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pkeinfo);
        Bundle Pokeport = getIntent().getExtras();
        Pokemon p = (Pokemon) Pokeport.getSerializable("pokemon");

        ImageView image = findViewById(R.id.imageView);
        TextView name = findViewById(R.id.name);
        TextView attack = findViewById(R.id.Attack);
        TextView defence = findViewById(R.id.Defence);
        TextView total = findViewById(R.id.Total);
        image.setImageResource(p.getImage());
        name.setText(p.getName());
        attack.setText("Attack: " + p.getAttack());
        defence.setText("Defence: " + p.getDefence());
        total.setText("Total: " + p.getTotal());
    }
}